CREATE SCHEMA `chihyeon` DEFAULT CHARACTER SET utf8 ;
use daerae;

create table chi_member(
id varchar(50) primary key,
name varchar(50)  not null,
email varchar(50) unique ,
pwd varchar(50)  not null,
delflag int(1) default 0,
auth int(1) default 3
);
delete from chi_member;
INSERT INTO chi_member (ID,NAME,EMAIL,PWD)
VALUES('sn001','소연','aa@naver.com','1234');

INSERT INTO chi_member (ID,NAME,EMAIL,PWD,AUTH)
VALUES('admin','치현','admin@naver.com','1234',1);

select * from chi_member where delflag=0;
commit;

SELECT ID,NAME,EMAIL,AUTH FROM  CHI_MEMBER
WHERE DELFLAG=0  and auth != 1 ORDER BY ID ;



create table chi_book(
isbn char(12) primary key,
title varchar(100) not null,
catalogue varchar(50) not null,
nation varchar(50),
publish_date date,
publisher varchar(100),
author varchar(100) not null,
price int(6) ,
currency char(6),
description varchar(4000)
);
INSERT INTO chi_book VALUES('1233-111-111','Java 완성','프로그래밍','국내도서',
         '2019.1.1','사무국','사무국',3000,'원','java를 마시자');
INSERT INTO chi_book VALUES('1233-111-123','Java와 함께','프로그래밍','국내도서',
         '2019.1.2','사무국','사무국',4000,'원','java와 동행');











