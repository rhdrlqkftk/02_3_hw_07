package com.ssafy.edu.service;

import java.util.List;

import com.ssafy.edu.model.Deps;
import com.ssafy.edu.model.Employees;
import com.ssafy.edu.model.Jobs;
//OCP -> ISP 
public interface IEmployeesService {
	public List<Employees> getEmpList ();
	public Employees getEmp (int employee_id);
	public List<Deps> getAllDeps();
	public List<Employees> getAllManagers();
	public List<Jobs> getAllJobs();
}
//http://192.168.28.129:8080/hellovues8