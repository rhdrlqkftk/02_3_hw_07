package com.ssafy.edu.controller;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.ssafy.edu.service.IEmployeesService;

@Controller
public class EmployeesController {
	private static final Logger logger = 
			LoggerFactory.getLogger(EmployeesController.class);
	
	@Autowired
	private IEmployeesService empservice;
	
	@RequestMapping(value = "emplist.do", 
			method = {RequestMethod.GET,RequestMethod.POST})
	public String emplist(Model model) {
		logger.info("Welcome EmployeesController emplist! "+ new Date());
		model.addAttribute("emps", empservice.getEmpList());
		return "emplist";
	}
	@RequestMapping(value = "empdetail.do", 
			method = {RequestMethod.GET,RequestMethod.POST})
	public String empdetail(int employee_id,Model model) {
		logger.info("Welcome EmployeesController empdetail! "+ new Date());
		model.addAttribute("emp", empservice.getEmp(employee_id));
		return "empdetail";
	}
	@RequestMapping(value = "addemp.do", 
			method = {RequestMethod.GET,RequestMethod.POST})
	public String addemp(Model model) {
		logger.info("Welcome EmployeesController addemp! "+ new Date());
		
		model.addAttribute("deps", empservice.getAllDeps());
		model.addAttribute("managers", empservice.getAllManagers());
		model.addAttribute("jobs", empservice.getAllJobs());
		
		return "addemp";
	}
	
}
