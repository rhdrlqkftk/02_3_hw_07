package com.ssafy.edu.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ssafy.edu.dao.EmployeesDaoImpl;
import com.ssafy.edu.model.Deps;
import com.ssafy.edu.model.Employees;
import com.ssafy.edu.model.Jobs;
@Service
public class EmployeesServiceImpl implements IEmployeesService {
	
	@Autowired    // 자동 DI 해줘~~~~   
	private EmployeesDaoImpl empdao;
	
	@Override
	@Transactional(readOnly=true)
	public List<Employees> getEmpList() {
		return empdao.getEmpList();
	}

	@Override
	@Transactional(readOnly=true)
	public Employees getEmp(int employee_id) {
		return empdao.getEmp( employee_id);
	}

	@Override
	public List<Deps> getAllDeps() {
		return empdao.getAllDeps();
	}

	@Override
	public List<Employees> getAllManagers() {
		return empdao.getAllManagers();
	}

	@Override
	public List<Jobs> getAllJobs() {
		return empdao.getAllJobs();
	}

}
