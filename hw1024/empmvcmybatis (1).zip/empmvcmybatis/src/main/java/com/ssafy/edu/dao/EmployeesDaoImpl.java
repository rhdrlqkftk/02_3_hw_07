package com.ssafy.edu.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ssafy.edu.model.Deps;
import com.ssafy.edu.model.Employees;
import com.ssafy.edu.model.Jobs;

@Repository
public class EmployeesDaoImpl {
	
	String ns="ssafy.employees.";
	@Autowired
	private SqlSession sqlSession;
	
	public List<Employees> getEmpList (){
		return sqlSession.selectList(ns+"getEmpList");
	}

	public Employees getEmp(int employee_id) {
		return sqlSession.selectOne(ns+"getEmp",employee_id);
	}

	public List<Deps> getAllDeps() {
		return sqlSession.selectList(ns+"getAllDeps");
	}

	public List<Employees> getAllManagers() {
		return sqlSession.selectList(ns+"getAllManagers");
	}

	public List<Jobs> getAllJobs() {
		return sqlSession.selectList(ns+"getAllJobs");
	}
	
}
